FakeOnline Standalone для мода bist v0.2 (xhatw)

• plugins/FakeOnline.so  — Linux (HostGTA)
• plugins/FakeOnline.dll — Windows (старая версия, ей нужен pawn)
• scriptfiles/fakeonline.ini — настройки

Используй .so — он работает БЕЗ filterscript и БЕЗ компиляции.

Под SA-MP 0.3.7-R2.
Фейк только в браузере (query), внутри сервер пустой.
