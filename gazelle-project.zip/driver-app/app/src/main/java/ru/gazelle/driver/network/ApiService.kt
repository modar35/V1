package ru.gazelle.driver.network

import ru.gazelle.driver.data.*
import retrofit2.http.*

interface ApiService {
    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): AuthResponse

    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): AuthResponse

    @GET("users/me")
    suspend fun me(): UserDto

    @PATCH("users/me/online")
    suspend fun setOnline(@Body body: Map<String, Boolean>)

    @PATCH("users/me/location")
    suspend fun updateLocation(@Body body: Map<String, Double>)

    @GET("orders/available")
    suspend fun availableOrders(): List<OrderDto>

    @GET("orders/mine/driver")
    suspend fun myOrders(): List<OrderDto>

    @PATCH("orders/{id}/accept")
    suspend fun acceptOrder(@Path("id") id: String): OrderDto

    @PATCH("orders/{id}/status")
    suspend fun updateStatus(@Path("id") id: String, @Body body: Map<String, String>): OrderDto
}
