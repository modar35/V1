package ru.gazelle.driver

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import ru.gazelle.driver.data.*
import ru.gazelle.driver.network.RetrofitClient
import ru.gazelle.driver.network.SocketManager
import ru.gazelle.driver.network.TokenStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TokenStore.init(this)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                val startDest = if (TokenStore.get() != null) "available" else "auth"
                NavHost(navController = nav, startDestination = startDest) {
                    composable("auth") { AuthScreen(nav) }
                    composable("available") { AvailableOrdersScreen(nav) }
                    composable("active/{id}") { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("id") ?: return@composable
                        ActiveOrderScreen(id)
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(nav: NavHostController) {
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(if (isRegister) "Регистрация водителя" else "Вход", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        if (isRegister) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = plate, onValueChange = { plate = it }, label = { Text("Госномер газели") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Пароль") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            scope.launch {
                try {
                    val resp = if (isRegister) {
                        RetrofitClient.api.register(RegisterRequest(phone, password, name, vehiclePlate = plate.ifBlank { null }))
                    } else {
                        RetrofitClient.api.login(LoginRequest(phone, password))
                    }
                    TokenStore.save(resp.token)
                    SocketManager.connect(resp.token)
                    nav.navigate("available") { popUpTo("auth") { inclusive = true } }
                } catch (e: Exception) {
                    error = "Ошибка: ${e.message}"
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isRegister) "Зарегистрироваться" else "Войти")
        }
        TextButton(onClick = { isRegister = !isRegister }) {
            Text(if (isRegister) "У меня уже есть аккаунт" else "Первый раз здесь? Регистрация")
        }
    }
}

@Composable
fun AvailableOrdersScreen(nav: NavHostController) {
    var orders by remember { mutableStateOf<List<OrderDto>>(emptyList()) }
    var myActive by remember { mutableStateOf<OrderDto?>(null) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    suspend fun reload() {
        loading = true
        try {
            orders = RetrofitClient.api.availableOrders()
            myActive = RetrofitClient.api.myOrders().firstOrNull { it.status == "accepted" || it.status == "in_progress" }
        } catch (_: Exception) {}
        loading = false
    }

    LaunchedEffect(Unit) {
        RetrofitClient.api.setOnline(mapOf("isOnline" to true))
        reload()
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Доступные заявки", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        myActive?.let { active ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("У вас есть активная заявка", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = { nav.navigate("active/${active.id}") }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Перейти к заявке")
                    }
                }
            }
        }
        if (loading) {
            CircularProgressIndicator()
        } else if (orders.isEmpty()) {
            Text("Новых заявок пока нет")
        } else {
            LazyColumn {
                items(orders) { order ->
                    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${order.fromAddress} → ${order.toAddress}", style = MaterialTheme.typography.titleMedium)
                            Text("Груз: ${order.cargoDescription}")
                            order.price?.let { Text("Цена: $it ₽") }
                            Button(
                                enabled = myActive == null,
                                onClick = {
                                    scope.launch {
                                        try {
                                            RetrofitClient.api.acceptOrder(order.id)
                                            nav.navigate("active/${order.id}")
                                        } catch (_: Exception) {}
                                    }
                                },
                                modifier = Modifier.padding(top = 8.dp)
                            ) { Text("Взять заявку") }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ActiveOrderScreen(orderId: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var order by remember { mutableStateOf<OrderDto?>(null) }
    val scope = rememberCoroutineScope()
    val fused = remember { LocationServices.getFusedLocationProviderClient(context) }

    suspend fun reload() {
        order = try { RetrofitClient.api.myOrders().firstOrNull { it.id == orderId } } catch (_: Exception) { null }
    }

    LaunchedEffect(Unit) { reload() }

    // Каждые 5 секунд шлём координаты водителя, пока заявка активна
    LaunchedEffect(order?.status) {
        while (order?.status == "accepted" || order?.status == "in_progress") {
            fused.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    SocketManager.sendLocation(orderId, loc.latitude, loc.longitude)
                    scope.launch {
                        try { RetrofitClient.api.updateLocation(mapOf("lat" to loc.latitude, "lng" to loc.longitude)) } catch (_: Exception) {}
                    }
                }
            }
            delay(5000)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        val o = order
        if (o == null) {
            CircularProgressIndicator()
            return@Column
        }
        Text("Заявка", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("${o.fromAddress} → ${o.toAddress}")
        Text("Груз: ${o.cargoDescription}")
        o.client?.let { Text("Клиент: ${it.name}, тел. ${it.phone}") }
        Text("Статус: ${o.status}")
        Spacer(Modifier.height(16.dp))
        if (o.status == "accepted") {
            Button(onClick = {
                scope.launch {
                    order = RetrofitClient.api.updateStatus(o.id, mapOf("status" to "in_progress"))
                }
            }) { Text("В пути") }
        }
        if (o.status == "in_progress") {
            Button(onClick = {
                scope.launch {
                    order = RetrofitClient.api.updateStatus(o.id, mapOf("status" to "delivered"))
                }
            }) { Text("Доставлено") }
        }
    }
}
