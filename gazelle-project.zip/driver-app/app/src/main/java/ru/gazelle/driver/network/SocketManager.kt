package ru.gazelle.driver.network

import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject

object SocketManager {
    private var socket: Socket? = null

    fun connect(token: String) {
        val opts = IO.Options()
        opts.query = "token=$token"
        socket = IO.socket(java.net.URI.create(ApiConfig.SOCKET_URL), opts)
        socket?.connect()
        socket?.emit("driver-online")
    }

    fun sendLocation(orderId: String, lat: Double, lng: Double) {
        val payload = JSONObject().apply {
            put("orderId", orderId)
            put("lat", lat)
            put("lng", lng)
        }
        socket?.emit("geo:update", payload)
    }

    fun disconnect() {
        socket?.disconnect()
        socket = null
    }
}
