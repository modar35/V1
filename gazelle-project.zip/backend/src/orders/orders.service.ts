import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderStatus } from '../entities/order.entity';
import { CreateOrderDto } from './dto/order.dto';
import { TrackingGateway } from '../tracking/tracking.gateway';

@Injectable()
export class OrdersService {
  constructor(
    @InjectRepository(Order) private ordersRepo: Repository<Order>,
    private trackingGateway: TrackingGateway,
  ) {}

  async create(clientId: string, dto: CreateOrderDto) {
    const order = this.ordersRepo.create({
      ...dto,
      clientId,
      status: OrderStatus.NEW,
    });
    const saved = await this.ordersRepo.save(order);
    // Уведомляем всех водителей онлайн о новой заявке
    this.trackingGateway.broadcastNewOrder(saved);
    return saved;
  }

  // Список доступных заявок для водителей (ещё никто не взял)
  findAvailable() {
    return this.ordersRepo.find({
      where: { status: OrderStatus.NEW },
      order: { createdAt: 'DESC' },
    });
  }

  findMyAsClient(clientId: string) {
    return this.ordersRepo.find({
      where: { clientId },
      order: { createdAt: 'DESC' },
    });
  }

  findMyAsDriver(driverId: string) {
    return this.ordersRepo.find({
      where: { driverId },
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string) {
    const order = await this.ordersRepo.findOne({ where: { id } });
    if (!order) throw new NotFoundException('Заявка не найдена');
    return order;
  }

  async accept(orderId: string, driverId: string) {
    const order = await this.findOne(orderId);
    if (order.status !== OrderStatus.NEW) {
      throw new BadRequestException('Заявку уже взяли или она недоступна');
    }
    order.driverId = driverId;
    order.status = OrderStatus.ACCEPTED;
    const saved = await this.ordersRepo.save(order);
    this.trackingGateway.broadcastOrderUpdate(saved);
    return saved;
  }

  async updateStatus(orderId: string, driverId: string, status: OrderStatus) {
    const order = await this.findOne(orderId);
    if (order.driverId !== driverId) {
      throw new ForbiddenException('Это не ваша заявка');
    }
    const allowed: Record<string, OrderStatus[]> = {
      [OrderStatus.ACCEPTED]: [OrderStatus.IN_PROGRESS, OrderStatus.CANCELLED],
      [OrderStatus.IN_PROGRESS]: [OrderStatus.DELIVERED, OrderStatus.CANCELLED],
    };
    const allowedNext = allowed[order.status] || [];
    if (!allowedNext.includes(status)) {
      throw new BadRequestException(
        `Нельзя перевести заявку из "${order.status}" в "${status}"`,
      );
    }
    order.status = status;
    const saved = await this.ordersRepo.save(order);
    this.trackingGateway.broadcastOrderUpdate(saved);
    return saved;
  }

  async cancelByClient(orderId: string, clientId: string) {
    const order = await this.findOne(orderId);
    if (order.clientId !== clientId) {
      throw new ForbiddenException('Это не ваша заявка');
    }
    if (order.status === OrderStatus.DELIVERED) {
      throw new BadRequestException('Доставленную заявку нельзя отменить');
    }
    order.status = OrderStatus.CANCELLED;
    const saved = await this.ordersRepo.save(order);
    this.trackingGateway.broadcastOrderUpdate(saved);
    return saved;
  }
}
