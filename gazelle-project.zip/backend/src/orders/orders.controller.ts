import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard, Roles, RolesGuard } from '../auth/guards';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/order.dto';
import { OrderStatus } from '../entities/order.entity';

@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('orders')
export class OrdersController {
  constructor(private ordersService: OrdersService) {}

  @Roles('client')
  @Post()
  create(@Req() req: any, @Body() dto: CreateOrderDto) {
    return this.ordersService.create(req.user.userId, dto);
  }

  @Roles('driver')
  @Get('available')
  available() {
    return this.ordersService.findAvailable();
  }

  @Roles('client')
  @Get('mine/client')
  mineClient(@Req() req: any) {
    return this.ordersService.findMyAsClient(req.user.userId);
  }

  @Roles('driver')
  @Get('mine/driver')
  mineDriver(@Req() req: any) {
    return this.ordersService.findMyAsDriver(req.user.userId);
  }

  @Get(':id')
  one(@Param('id') id: string) {
    return this.ordersService.findOne(id);
  }

  @Roles('driver')
  @Patch(':id/accept')
  accept(@Req() req: any, @Param('id') id: string) {
    return this.ordersService.accept(id, req.user.userId);
  }

  @Roles('driver')
  @Patch(':id/status')
  updateStatus(
    @Req() req: any,
    @Param('id') id: string,
    @Body('status') status: OrderStatus,
  ) {
    return this.ordersService.updateStatus(id, req.user.userId, status);
  }

  @Roles('client')
  @Patch(':id/cancel')
  cancel(@Req() req: any, @Param('id') id: string) {
    return this.ordersService.cancelByClient(id, req.user.userId);
  }
}
