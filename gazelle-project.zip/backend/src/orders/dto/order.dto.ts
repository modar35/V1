import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateOrderDto {
  @IsString() @IsNotEmpty() fromAddress: string;
  @IsNumber() fromLat: number;
  @IsNumber() fromLng: number;

  @IsString() @IsNotEmpty() toAddress: string;
  @IsNumber() toLat: number;
  @IsNumber() toLng: number;

  @IsString() @IsNotEmpty() cargoDescription: string;

  @IsOptional() @IsNumber() weightKg?: number;
  @IsOptional() @IsNumber() price?: number;
  @IsOptional() @IsString() comment?: string;
}

export class UpdateLocationDto {
  @IsNumber() lat: number;
  @IsNumber() lng: number;
}
