import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { User } from './user.entity';

export enum OrderStatus {
  NEW = 'new', // создана клиентом, ждёт водителя
  ACCEPTED = 'accepted', // водитель взял заявку
  IN_PROGRESS = 'in_progress', // водитель едет / везёт груз
  DELIVERED = 'delivered', // доставлено
  CANCELLED = 'cancelled', // отменена клиентом или водителем
}

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, { eager: true })
  @JoinColumn({ name: 'clientId' })
  client: User;

  @Column()
  clientId: string;

  @ManyToOne(() => User, { eager: true, nullable: true })
  @JoinColumn({ name: 'driverId' })
  driver: User | null;

  @Column({ nullable: true })
  driverId: string | null;

  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.NEW })
  status: OrderStatus;

  // Точка А
  @Column()
  fromAddress: string;

  @Column({ type: 'double precision' })
  fromLat: number;

  @Column({ type: 'double precision' })
  fromLng: number;

  // Точка Б
  @Column()
  toAddress: string;

  @Column({ type: 'double precision' })
  toLat: number;

  @Column({ type: 'double precision' })
  toLng: number;

  @Column()
  cargoDescription: string;

  @Column({ type: 'double precision', nullable: true })
  weightKg: number | null;

  @Column({ type: 'integer', nullable: true })
  price: number | null;

  @Column({ nullable: true })
  comment: string | null;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamptz' })
  updatedAt: Date;
}
