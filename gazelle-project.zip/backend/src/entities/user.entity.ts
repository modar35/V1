import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

export enum UserRole {
  CLIENT = 'client',
  DRIVER = 'driver',
}

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  phone: string;

  @Column()
  passwordHash: string;

  @Column()
  name: string;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  // Поля актуальны только для водителей
  @Column({ nullable: true })
  vehiclePlate: string | null;

  @Column({ nullable: true })
  vehicleModel: string | null;

  @Column({ type: 'double precision', nullable: true })
  lastLat: number | null;

  @Column({ type: 'double precision', nullable: true })
  lastLng: number | null;

  @Column({ type: 'timestamptz', nullable: true })
  lastLocationAt: Date | null;

  // Водитель может быть онлайн (готов брать заявки) или офлайн
  @Column({ default: false })
  isOnline: boolean;

  @CreateDateColumn({ type: 'timestamptz' })
  createdAt: Date;
}
