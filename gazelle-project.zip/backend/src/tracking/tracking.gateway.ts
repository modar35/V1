import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Injectable, Logger } from '@nestjs/common';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { Order } from '../entities/order.entity';

/**
 * Протокол (комнаты Socket.IO):
 * - "drivers-online"  — все водители, которые сейчас на смене; сюда шлём новые заявки
 * - "order-<id>"      — клиент и назначенный водитель конкретной заявки;
 *                       сюда шлём geo:update и order:update
 *
 * Клиент должен подключаться с ?token=<JWT> в query, затем эмитить:
 *   "join-order"   { orderId }         — чтобы получать обновления по заявке
 *   "driver-online" { }                — водитель встал на смену
 *   "geo:update"   { orderId, lat, lng } — водитель шлёт свои координаты по активной заявке
 */
@Injectable()
@WebSocketGateway({ cors: { origin: '*' } })
export class TrackingGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private logger = new Logger('TrackingGateway');

  constructor(private jwtService: JwtService) {}

  handleConnection(client: Socket) {
    try {
      const token = client.handshake.query.token as string;
      const payload = this.jwtService.verify(token);
      (client.data as any).userId = payload.sub;
      (client.data as any).role = payload.role;
    } catch (e) {
      this.logger.warn(`Неавторизованное подключение: ${client.id}`);
      client.disconnect();
    }
  }

  handleDisconnect(client: Socket) {
    client.leave('drivers-online');
  }

  @SubscribeMessage('driver-online')
  onDriverOnline(@ConnectedSocket() client: Socket) {
    if (client.data.role === 'driver') {
      client.join('drivers-online');
    }
  }

  @SubscribeMessage('join-order')
  onJoinOrder(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { orderId: string },
  ) {
    client.join(`order-${body.orderId}`);
  }

  @SubscribeMessage('geo:update')
  onGeoUpdate(
    @ConnectedSocket() client: Socket,
    @MessageBody() body: { orderId: string; lat: number; lng: number },
  ) {
    // Ретранслируем координаты водителя клиенту, который следит за этой заявкой
    this.server.to(`order-${body.orderId}`).emit('geo:update', {
      orderId: body.orderId,
      lat: body.lat,
      lng: body.lng,
      at: new Date().toISOString(),
    });
  }

  // Вызывается из OrdersService при создании новой заявки
  broadcastNewOrder(order: Order) {
    this.server.to('drivers-online').emit('order:new', order);
  }

  // Вызывается из OrdersService при смене статуса заявки
  broadcastOrderUpdate(order: Order) {
    this.server.to(`order-${order.id}`).emit('order:update', order);
  }
}
