import { Body, Controller, Get, Patch, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards';
import { UsersService } from './users.service';
import { UpdateLocationDto } from '../orders/dto/order.dto';

@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Get('me')
  me(@Req() req: any) {
    return this.usersService.me(req.user.userId);
  }

  @Patch('me/location')
  updateLocation(@Req() req: any, @Body() dto: UpdateLocationDto) {
    return this.usersService.updateLocation(req.user.userId, dto.lat, dto.lng);
  }

  @Patch('me/online')
  setOnline(@Req() req: any, @Body('isOnline') isOnline: boolean) {
    return this.usersService.setOnline(req.user.userId, isOnline);
  }
}
