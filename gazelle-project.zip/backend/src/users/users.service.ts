import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../entities/user.entity';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private usersRepo: Repository<User>) {}

  async me(id: string) {
    const user = await this.usersRepo.findOne({ where: { id } });
    if (!user) throw new NotFoundException('Пользователь не найден');
    const { passwordHash, ...safe } = user;
    return safe;
  }

  async updateLocation(id: string, lat: number, lng: number) {
    await this.usersRepo.update(id, {
      lastLat: lat,
      lastLng: lng,
      lastLocationAt: new Date(),
    });
    return { ok: true };
  }

  async setOnline(id: string, isOnline: boolean) {
    await this.usersRepo.update(id, { isOnline });
    return { ok: true };
  }
}
