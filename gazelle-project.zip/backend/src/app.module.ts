import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { Order } from './entities/order.entity';
import { AuthModule } from './auth/auth.module';
import { OrdersModule } from './orders/orders.module';
import { UsersModule } from './users/users.module';
import { TrackingModule } from './tracking/tracking.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432', 10),
      username: process.env.DB_USER || 'gazelle',
      password: process.env.DB_PASSWORD || 'gazelle',
      database: process.env.DB_NAME || 'gazelle',
      entities: [User, Order],
      synchronize: true, // MVP: авто-миграции. На проде заменить на настоящие миграции.
    }),
    AuthModule,
    OrdersModule,
    UsersModule,
    TrackingModule,
  ],
})
export class AppModule {}
