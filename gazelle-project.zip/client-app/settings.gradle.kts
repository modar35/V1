pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Репозиторий Яндекс.MapKit
        maven { url = uri("https://maven.yandex.net/repository/maps-mobile/") }
    }
}

rootProject.name = "GazelleClient"
include(":app")
