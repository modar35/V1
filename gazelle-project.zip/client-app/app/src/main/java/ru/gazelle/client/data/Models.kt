package ru.gazelle.client.data

data class UserDto(
    val id: String,
    val phone: String,
    val name: String,
    val role: String
)

data class AuthResponse(
    val token: String,
    val user: UserDto
)

data class RegisterRequest(
    val phone: String,
    val password: String,
    val name: String,
    val role: String = "client"
)

data class LoginRequest(
    val phone: String,
    val password: String
)

data class OrderDto(
    val id: String,
    val status: String,
    val fromAddress: String,
    val fromLat: Double,
    val fromLng: Double,
    val toAddress: String,
    val toLat: Double,
    val toLng: Double,
    val cargoDescription: String,
    val weightKg: Double?,
    val price: Int?,
    val comment: String?,
    val driver: UserDto?,
    val createdAt: String
)

data class CreateOrderRequest(
    val fromAddress: String,
    val fromLat: Double,
    val fromLng: Double,
    val toAddress: String,
    val toLat: Double,
    val toLng: Double,
    val cargoDescription: String,
    val weightKg: Double? = null,
    val price: Int? = null,
    val comment: String? = null
)
