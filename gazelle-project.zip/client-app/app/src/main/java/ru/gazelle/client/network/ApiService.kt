package ru.gazelle.client.network

import ru.gazelle.client.data.*
import retrofit2.http.*

interface ApiService {
    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): AuthResponse

    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): AuthResponse

    @GET("users/me")
    suspend fun me(): UserDto

    @POST("orders")
    suspend fun createOrder(@Body body: CreateOrderRequest): OrderDto

    @GET("orders/mine/client")
    suspend fun myOrders(): List<OrderDto>

    @PATCH("orders/{id}/cancel")
    suspend fun cancelOrder(@Path("id") id: String): OrderDto
}
