package ru.gazelle.client.network

import android.content.Context
import android.content.SharedPreferences
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * ВАЖНО: замените BASE_URL на адрес вашего backend.
 * Для локального теста на эмуляторе Android используйте 10.0.2.2 вместо localhost.
 * Для реального устройства — публичный адрес/домен вашего сервера (см. README в backend/).
 */
object ApiConfig {
    const val BASE_URL = "http://10.0.2.2:3000/"
    const val SOCKET_URL = "http://10.0.2.2:3000"
}

object TokenStore {
    private const val PREFS = "gazelle_prefs"
    private const val KEY_TOKEN = "token"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    fun save(token: String) = prefs.edit().putString(KEY_TOKEN, token).apply()
    fun get(): String? = prefs.getString(KEY_TOKEN, null)
    fun clear() = prefs.edit().remove(KEY_TOKEN).apply()
}

private class AuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder = chain.request().newBuilder()
        TokenStore.get()?.let { builder.addHeader("Authorization", "Bearer $it") }
        return chain.proceed(builder.build())
    }
}

object RetrofitClient {
    val api: ApiService by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor())
            .addInterceptor(logging)
            .build()
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
