package ru.gazelle.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch
import ru.gazelle.client.data.*
import ru.gazelle.client.network.ApiConfig
import ru.gazelle.client.network.RetrofitClient
import ru.gazelle.client.network.TokenStore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TokenStore.init(this)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                val startDest = if (TokenStore.get() != null) "orders" else "auth"
                NavHost(navController = nav, startDestination = startDest) {
                    composable("auth") { AuthScreen(nav) }
                    composable("orders") { OrdersScreen(nav) }
                    composable("create") { CreateOrderScreen(nav) }
                }
            }
        }
    }
}

// ---------- Экран входа / регистрации ----------
@Composable
fun AuthScreen(nav: NavHostController) {
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(if (isRegister) "Регистрация заказчика" else "Вход", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        if (isRegister) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Пароль") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            scope.launch {
                try {
                    val resp = if (isRegister) {
                        RetrofitClient.api.register(RegisterRequest(phone, password, name))
                    } else {
                        RetrofitClient.api.login(LoginRequest(phone, password))
                    }
                    TokenStore.save(resp.token)
                    nav.navigate("orders") { popUpTo("auth") { inclusive = true } }
                } catch (e: Exception) {
                    error = "Ошибка: ${e.message}"
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isRegister) "Зарегистрироваться" else "Войти")
        }
        TextButton(onClick = { isRegister = !isRegister }) {
            Text(if (isRegister) "У меня уже есть аккаунт" else "Первый раз здесь? Регистрация")
        }
    }
}

// ---------- Список заявок клиента ----------
@Composable
fun OrdersScreen(nav: NavHostController) {
    var orders by remember { mutableStateOf<List<OrderDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    suspend fun reload() {
        loading = true
        orders = try { RetrofitClient.api.myOrders() } catch (e: Exception) { emptyList() }
        loading = false
    }

    LaunchedEffect(Unit) { reload() }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { nav.navigate("create") }, text = { Text("Новая заявка") }, icon = {})
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            Text("Мои заявки", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            if (loading) {
                CircularProgressIndicator()
            } else if (orders.isEmpty()) {
                Text("Заявок пока нет. Создайте первую!")
            } else {
                LazyColumn {
                    items(orders) { order -> OrderCard(order) }
                }
            }
        }
    }
}

@Composable
fun OrderCard(order: OrderDto) {
    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text("${order.fromAddress} → ${order.toAddress}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text("Груз: ${order.cargoDescription}")
            Text("Статус: ${statusLabel(order.status)}")
            order.driver?.let { Text("Водитель: ${it.name}") }
        }
    }
}

fun statusLabel(status: String): String = when (status) {
    "new" -> "Ищем водителя"
    "accepted" -> "Водитель назначен"
    "in_progress" -> "Везёт груз"
    "delivered" -> "Доставлено"
    "cancelled" -> "Отменена"
    else -> status
}

// ---------- Создание заявки ----------
// Примечание: для боевого варианта здесь должна быть карта Яндекс.MapKit с выбором точек
// A и Б тапом по карте (см. README раздел "Карта"). Сейчас поля вводятся текстом для MVP.
@Composable
fun CreateOrderScreen(nav: NavHostController) {
    var fromAddress by remember { mutableStateOf("") }
    var toAddress by remember { mutableStateOf("") }
    var cargo by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Новая заявка", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = fromAddress, onValueChange = { fromAddress = it }, label = { Text("Адрес откуда") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = toAddress, onValueChange = { toAddress = it }, label = { Text("Адрес куда") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = cargo, onValueChange = { cargo = it }, label = { Text("Что везём") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Комментарий (необязательно)") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            scope.launch {
                try {
                    // TODO: заменить заглушки координат на реальные, полученные с карты/геокодера
                    RetrofitClient.api.createOrder(
                        CreateOrderRequest(
                            fromAddress = fromAddress, fromLat = 55.7558, fromLng = 37.6173,
                            toAddress = toAddress, toLat = 55.7600, toLng = 37.6200,
                            cargoDescription = cargo, comment = comment.ifBlank { null }
                        )
                    )
                    nav.popBackStack()
                } catch (e: Exception) {
                    error = "Ошибка: ${e.message}"
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Создать заявку")
        }
    }
}
